<?php

	// DB parameters
	define("DB_HOST", "localhost");
	define("DB_LOGIN", "root");
	define("DB_PWD", "root");
	define("DB_NAME", "enigmahack");

?>
